# VideoEditorPro (Starter Template)

This is a starter **Pro Video Editor** Android project template (Kotlin) that demonstrates:
- Integration with **mobile-ffmpeg** (trim, merge via FFmpeg commands)
- Simple UI to pick videos, trim first 5s, and merge two selected videos
- Example code places where you can extend features: filters, transitions, text overlays, speed control

## How to open & build
1. Install Android Studio and Android SDK (compileSdk 33).
2. Open this folder as a project.
3. Gradle will download dependencies including mobile-ffmpeg (this increases APK size).
4. Run on an Android device (minSdk 21).

## Notes & Next steps
- The app uses `com.arthenica:mobile-ffmpeg-full:4.4.LTS`. You can pick a lighter package to reduce APK size.
- For production you will need to handle runtime permissions, background tasks, progress updates, and robust URI handling.
- For filters/transitions consider using FFmpeg complex filters or GPU-accelerated libraries.
- This template writes temporary files to external cache; ensure cleanup and storage permissions in production.

## Files included
- app/src/main/AndroidManifest.xml
- app/src/main/java/com/example/videoeditorpro/MainActivity.kt
- app/src/main/res/layout/activity_main.xml
- build.gradle (project + app)
- settings.gradle

Enjoy! — AI Assistant

package com.example.videoeditorpro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.arthenica.mobileffmpeg.Config
import com.arthenica.mobileffmpeg.FFmpeg

class MainActivity : AppCompatActivity() {

    private var inputUri1: Uri? = null
    private var inputUri2: Uri? = null
    private lateinit var statusView: TextView

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            if (inputUri1 == null) {
                inputUri1 = it
                statusView.append("\nSelected file 1: ${getFileName(it)}")
            } else {
                inputUri2 = it
                statusView.append("\nSelected file 2: ${getFileName(it)}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO
        ), 1)

        statusView = findViewById(R.id.status)
        val btnPick = findViewById<Button>(R.id.btnPick)
        val btnTrim = findViewById<Button>(R.id.btnTrim)
        val btnMerge = findViewById<Button>(R.id.btnMerge)

        btnPick.setOnClickListener {
            pickFile.launch("video/*")
        }

        btnTrim.setOnClickListener {
            if (inputUri1 == null) {
                statusView.append("\nPick a video first.")
                return@setOnClickListener
            }
            val output = "${externalCacheDir?.absolutePath}/trim_output.mp4"
            val cmd = arrayOf("-i", getPathFromUri(inputUri1!!), "-ss", "0", "-t", "5", "-c", "copy", output)
            statusView.append("\nRunning trim...")
            Thread {
                val rc = FFmpeg.execute(cmd)
                runOnUiThread {
                    statusView.append("\nTrim complete. rc=$rc output=$output")
                }
            }.start()
        }

        btnMerge.setOnClickListener {
            if (inputUri1 == null || inputUri2 == null) {
                statusView.append("\nPick two videos to merge.")
                return@setOnClickListener
            }
            val listFile = "${externalCacheDir?.absolutePath}/mylist.txt"
            val out = "${externalCacheDir?.absolutePath}/merged.mp4"
            val p1 = getPathFromUri(inputUri1!!)
            val p2 = getPathFromUri(inputUri2!!)
            val content = "file '$p1'\nfile '$p2'\n"
            java.io.File(listFile).writeText(content)
            val cmd = arrayOf("-f", "concat", "-safe", "0", "-i", listFile, "-c", "copy", out)
            statusView.append("\nRunning merge...")
            Thread {
                val rc = FFmpeg.execute(cmd)
                runOnUiThread {
                    statusView.append("\nMerge complete. rc=$rc output=$out")
                }
            }.start()
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "unknown"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) {
                name = cursor.getString(idx)
            }
        }
        return name
    }

    private fun getPathFromUri(uri: Uri): String {
        val input = contentResolver.openInputStream(uri)!!
        val out = java.io.File(externalCacheDir, "input_${System.currentTimeMillis()}.mp4")
        input.use { inp ->
            out.outputStream().use { outp ->
                inp.copyTo(outp)
            }
        }
        return out.absolutePath
    }
}
